package com.cs.reliquia.mixin;

import com.cs.reliquia.CsReliquia;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin {

    // Lava, fogo, cacto, explosão etc. não causam dano ao item no chão
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void cs$semDano(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        ItemEntity self = (ItemEntity) (Object) this;
        if (CsReliquia.isReliquia(self.getStack())) {
            cir.setReturnValue(false);
        }
    }

    // Nunca some do chão (despawn)
    @Inject(method = "tick", at = @At("HEAD"))
    private void cs$semDespawn(CallbackInfo ci) {
        ItemEntity self = (ItemEntity) (Object) this;
        if (CsReliquia.isReliquia(self.getStack())) {
            self.setNeverDespawn();
        }
    }
}
