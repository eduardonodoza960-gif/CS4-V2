package com.cs.reliquia.mixin;

import com.cs.reliquia.CsReliquia;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TridentEntity.class)
public abstract class TridentEntityMixin {

    @Shadow
    private ItemStack tridentStack;

    @Inject(method = "onEntityHit", at = @At("HEAD"))
    private void cs$aoAcertar(EntityHitResult hit, CallbackInfo ci) {
        TridentEntity self = (TridentEntity) (Object) this;
        if (self.world.isClient || !CsReliquia.temId(tridentStack, CsReliquia.TRIDENTE_ID)) return;

        if (hit.getEntity() instanceof LivingEntity alvo) {
            // Cansaço de mineração 3 por 10 segundos
            alvo.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 200, 2), self.getOwner());

            // Tempestade + céu aberto = o Raio (Conduíte/Channeling) vai cair: marca o jogador
            if (alvo instanceof ServerPlayerEntity jogador
                    && self.world.isThundering()
                    && self.world.isSkyVisible(alvo.getBlockPos())) {
                CsReliquia.marcarRaio(jogador.getUuid(), ((ServerWorld) self.world).getServer().getTicks());
            }
        }
    }
}
