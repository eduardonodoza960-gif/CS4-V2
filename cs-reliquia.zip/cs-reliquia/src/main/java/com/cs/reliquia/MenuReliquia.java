package com.cs.reliquia;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;

/** Menu onde o item nunca acaba: clicar no item dá uma cópia e o menu continua igual. */
public class MenuReliquia extends GenericContainerScreenHandler {

    private final int tamanhoMenu;

    public MenuReliquia(int syncId, PlayerInventory inv, Inventory menu, int linhas) {
        super(linhas == 2 ? ScreenHandlerType.GENERIC_9X2 : ScreenHandlerType.GENERIC_9X3, syncId, inv, menu, linhas);
        this.tamanhoMenu = linhas * 9;
    }

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex >= 0 && slotIndex < tamanhoMenu) {
            if (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE
                    || actionType == SlotActionType.SWAP || actionType == SlotActionType.THROW) {
                ItemStack item = this.slots.get(slotIndex).getStack();
                if (!item.isEmpty()) {
                    player.getInventory().offerOrDrop(item.copy());
                }
            }
            this.syncState();
            return;
        }
        if (actionType == SlotActionType.PICKUP_ALL) {
            this.syncState();
            return;
        }
        super.onSlotClick(slotIndex, button, actionType, player);
    }
}
