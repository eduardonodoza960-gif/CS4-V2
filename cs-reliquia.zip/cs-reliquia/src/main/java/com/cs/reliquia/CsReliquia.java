package com.cs.reliquia;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.potion.PotionUtil;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.literal;

public class CsReliquia implements ModInitializer {

    public static final String TAG = "CsItem";
    public static final String ESPADA_ID = "espada_cacador";
    public static final String PENA_ID = "pena_lendaria";
    public static final String ESCUDO_ID = "escudo_lendario";
    public static final String POCAO_ID = "pocao_lendaria";
    public static final String TRIDENTE_ID = "tridente_lendario";
    public static final String PICARETA_ID = "picareta_lendaria";
    public static final String CAPACETE_ID = "capacete_gemeos";

    // ---- Rajada do Warden ----
    private static final double ALCANCE = 15.0;
    private static final float DANO = 3.5f;
    private static final double KB_HORIZONTAL = 1.2;
    private static final double KB_VERTICAL = 0.5;
    private static final int COOLDOWN_TICKS = 40;

    private final Map<UUID, Integer> ultimoUso = new HashMap<>();

    // jogadores marcados pelo Tridente Lendário em tempestade (UUID -> tick)
    private static final Map<UUID, Integer> RAIO_MARCADO = new HashMap<>();
    // jogadores usando o Capacete dos Gêmeos (estado do último tick)
    private static final Set<UUID> GEMEOS = new HashSet<>();

    public static void marcarRaio(UUID uuid, int tick) {
        RAIO_MARCADO.put(uuid, tick);
    }

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(literal("cs4").executes(ctx -> {
                abrirMenu(ctx.getSource().getPlayerOrThrow());
                return 1;
            }))
        );

        // "Comando de repetição": roda todo tick no servidor
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                ItemStack main = player.getMainHandStack();
                ItemStack off = player.getOffHandStack();

                if (temId(main, ESPADA_ID) || temId(off, ESPADA_ID)) {
                    aplicar(player, StatusEffects.BAD_OMEN, 5, 20);    // Mau Presságio 6, 1s
                }
                if (temId(main, PENA_ID) || temId(off, PENA_ID)) {
                    aplicar(player, StatusEffects.LEVITATION, 12, 80); // Levitação 13, 4s
                }

                // Capacete dos Gêmeos
                if (temId(player.getEquippedStack(EquipmentSlot.HEAD), CAPACETE_ID)) {
                    GEMEOS.add(player.getUuid());
                    aplicar(player, StatusEffects.WATER_BREATHING, 0, 40); // respiração infinita
                } else {
                    GEMEOS.remove(player.getUuid());
                }
            }
        });

        // Botão direito
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient || !(player instanceof ServerPlayerEntity sp)) {
                return TypedActionResult.pass(stack);
            }

            if (temId(stack, ESCUDO_ID)) {
                int agora = sp.getServer().getTicks();
                Integer ultimo = ultimoUso.get(sp.getUuid());
                if (ultimo == null || agora - ultimo >= COOLDOWN_TICKS) {
                    ultimoUso.put(sp.getUuid(), agora);
                    soltarRajada(sp);
                }
                return TypedActionResult.pass(stack); // o escudo continua defendendo
            }

            if (temId(stack, POCAO_ID)) {
                lancarPocao(sp, stack);
                return TypedActionResult.success(stack);
            }
            return TypedActionResult.pass(stack);
        });

        // Tridente Lendário na mão: cansaço 3 por 10s ao bater
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient && entity instanceof LivingEntity alvo
                    && temId(player.getStackInHand(hand), TRIDENTE_ID)) {
                alvo.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 200, 2), player);
            }
            return ActionResult.PASS;
        });

        // Mortes: Raio do Tridente apaga os itens + Gêmeos morrem juntos
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof ServerPlayerEntity morto)) return;
            MinecraftServer server = morto.getServer();

            Integer marca = RAIO_MARCADO.remove(morto.getUuid());
            if (marca != null && server.getTicks() - marca <= 60) {
                morto.getInventory().clear();
                ServerWorld mundo = (ServerWorld) morto.world;
                List<ItemEntity> drops = mundo.getEntitiesByClass(ItemEntity.class,
                    morto.getBoundingBox().expand(4.0), i -> i.getItemAge() <= 5);
                for (ItemEntity drop : drops) drop.discard();
            }

            if (GEMEOS.remove(morto.getUuid())) {
                for (ServerPlayerEntity outro : server.getPlayerManager().getPlayerList()) {
                    if (outro != morto && outro.isAlive() && GEMEOS.contains(outro.getUuid())) {
                        GEMEOS.remove(outro.getUuid());
                        outro.damage(DamageSource.OUT_OF_WORLD, Float.MAX_VALUE);
                    }
                }
            }
        });
    }

    private static void aplicar(ServerPlayerEntity player, StatusEffect efeito, int amplificador, int duracao) {
        StatusEffectInstance atual = player.getStatusEffect(efeito);
        if (atual == null || atual.getDuration() <= 10 || atual.getAmplifier() != amplificador) {
            player.addStatusEffect(new StatusEffectInstance(efeito, duracao, amplificador, false, false, true));
        }
    }

    // ---------- Poção Lendária: item splash, arremesso lingering ----------
    private void lancarPocao(ServerPlayerEntity player, ItemStack stack) {
        ServerWorld world = (ServerWorld) player.world;

        ItemStack lingering = new ItemStack(Items.LINGERING_POTION);
        lingering.setNbt(stack.getNbt().copy()); // mantém cor e efeito de cegueira

        PotionEntity entity = new PotionEntity(world, player);
        entity.setItem(lingering);
        entity.setVelocity(player, player.getPitch(), player.getYaw(), -20.0F, 0.5F, 1.0F);
        world.spawnEntity(entity);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_LINGERING_POTION_THROW, SoundCategory.PLAYERS, 0.5F,
            0.4F / (world.getRandom().nextFloat() * 0.4F + 0.8F));

        if (!player.getAbilities().creativeMode) stack.decrement(1);
    }

    // ---------- Rajada do Warden ----------
    private void soltarRajada(ServerPlayerEntity player) {
        ServerWorld world = (ServerWorld) player.world;
        Vec3d inicio = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0f);
        Vec3d fim = inicio.add(dir.multiply(ALCANCE));

        var bloco = world.raycast(new RaycastContext(inicio, fim,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (bloco.getType() != HitResult.Type.MISS) {
            fim = bloco.getPos();
        }
        double comprimento = inicio.distanceTo(fim);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 3.0f, 1.0f);

        for (int i = 1; i < (int) Math.floor(comprimento); i++) {
            Vec3d p = inicio.add(dir.multiply(i));
            world.spawnParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }

        Box area = new Box(inicio, fim).expand(1.5);
        List<Entity> alvos = world.getOtherEntities(player, area,
            e -> e instanceof LivingEntity && e.isAlive());
        for (Entity e : alvos) {
            if (e.getBoundingBox().expand(0.6).raycast(inicio, fim).isEmpty()) continue;
            LivingEntity alvo = (LivingEntity) e;

            alvo.damage(DamageSource.sonicBoom(player), DANO);

            Vec3d horizontal = new Vec3d(dir.x, 0, dir.z);
            horizontal = horizontal.lengthSquared() < 1.0E-4 ? dir : horizontal.normalize();
            alvo.setVelocity(horizontal.x * KB_HORIZONTAL, KB_VERTICAL, horizontal.z * KB_HORIZONTAL);
            alvo.velocityModified = true;
            if (alvo instanceof ServerPlayerEntity alvoPlayer) {
                alvoPlayer.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(alvoPlayer));
            }
        }
    }

    // ---------- Menu ----------
    private void abrirMenu(ServerPlayerEntity player) {
        // inventário do menu que não aceita itens de volta
        SimpleInventory menu = new SimpleInventory(18) {
            @Override
            public boolean isValid(int slot, ItemStack stack) {
                return false;
            }
        };
        menu.setStack(0, criarEspada());
        menu.setStack(1, criarPena());
        menu.setStack(2, criarEscudo());
        menu.setStack(3, criarPocao());
        menu.setStack(4, criarTridente());
        menu.setStack(5, criarPicareta());
        menu.setStack(6, criarCapacete());

        Text titulo = Text.literal("CS").formatted(Formatting.GOLD, Formatting.BOLD)
            .append(Text.literal("» ").formatted(Formatting.GRAY))
            .append(Text.literal("Relíquia").formatted(Formatting.DARK_GRAY));

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, inv, p) -> new MenuReliquia(syncId, inv, menu, 2), titulo));
    }

    /** Base comum: nome amarelo/negrito/sublinhado, inquebrável, tag. flagsExtras soma em HideFlags. */
    private ItemStack base(Item material, String nome, String id, int flagsExtras) {
        ItemStack stack = new ItemStack(material);
        stack.setCustomName(Text.literal(nome)
            .setStyle(Style.EMPTY.withColor(Formatting.YELLOW)
                .withBold(true).withUnderline(true).withItalic(false)));
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putBoolean("Unbreakable", true);
        nbt.putInt("HideFlags", 1 | 4 | flagsExtras); // 1 encantos, 4 inquebrável
        nbt.putString(TAG, id);
        return stack;
    }

    private ItemStack criarEspada() {
        ItemStack s = base(Items.GOLDEN_SWORD, "Espada do Caçador", ESPADA_ID, 0);
        s.addEnchantment(Enchantments.KNOCKBACK, 10);
        return s;
    }

    private ItemStack criarPena() {
        ItemStack s = base(Items.FEATHER, "Pena Lendária", PENA_ID, 0);
        s.addEnchantment(Enchantments.UNBREAKING, 1); // só brilho
        return s;
    }

    private ItemStack criarEscudo() {
        ItemStack s = base(Items.SHIELD, "Escudo Lendário", ESCUDO_ID, 0);
        s.addEnchantment(Enchantments.UNBREAKING, 1); // só brilho
        return s;
    }

    private ItemStack criarPocao() {
        ItemStack s = base(Items.SPLASH_POTION, "Poção Lendária", POCAO_ID, 32); // 32 esconde efeitos
        s.getOrCreateNbt().putInt("CustomPotionColor", 16711935);
        // Nuvem (lingering) aplica 1/4 da duração: 800 ticks -> 10 segundos de cegueira
        PotionUtil.setCustomPotionEffects(s, List.of(new StatusEffectInstance(StatusEffects.BLINDNESS, 800, 0)));
        return s;
    }

    private ItemStack criarTridente() {
        ItemStack s = base(Items.TRIDENT, "Tridente Lendário", TRIDENTE_ID, 0);
        s.addEnchantment(Enchantments.IMPALING, 5);
        s.addEnchantment(Enchantments.LOYALTY, 3);
        s.addEnchantment(Enchantments.CHANNELING, 1);
        s.addEnchantment(Enchantments.UNBREAKING, 3);
        s.addEnchantment(Enchantments.MENDING, 1);
        return s;
    }

    private ItemStack criarPicareta() {
        ItemStack s = base(Items.IRON_PICKAXE, "Picareta Lendária", PICARETA_ID, 0);
        s.addEnchantment(Enchantments.EFFICIENCY, 13);
        return s;
    }

    private ItemStack criarCapacete() {
        ItemStack s = base(Items.TURTLE_HELMET, "Capacete Lendário dos Gêmeos", CAPACETE_ID, 2); // 2 esconde atributos
        // +5 corações (10 de vida)
        s.addAttributeModifier(EntityAttributes.GENERIC_MAX_HEALTH,
            new EntityAttributeModifier(UUID.fromString("5d6f0ba2-1384-4879-8f22-2b6a1d1e0a01"),
                "Gemeos vida", 10.0, EntityAttributeModifier.Operation.ADDITION), EquipmentSlot.HEAD);
        // mantém a armadura original do capacete de tartaruga
        s.addAttributeModifier(EntityAttributes.GENERIC_ARMOR,
            new EntityAttributeModifier(UUID.fromString("5d6f0ba2-1384-4879-8f22-2b6a1d1e0a02"),
                "Gemeos armadura", 2.0, EntityAttributeModifier.Operation.ADDITION), EquipmentSlot.HEAD);
        return s;
    }

    public static boolean temId(ItemStack stack, String id) {
        return !stack.isEmpty() && stack.hasNbt() && id.equals(stack.getNbt().getString(TAG));
    }

    /** Qualquer item da Relíquia (usado pelo mixin de indestrutibilidade). */
    public static boolean isReliquia(ItemStack stack) {
        return !stack.isEmpty() && stack.hasNbt() && !stack.getNbt().getString(TAG).isEmpty();
    }
}
